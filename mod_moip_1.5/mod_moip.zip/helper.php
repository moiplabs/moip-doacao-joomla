<?php

class modMoipHelper
{

}

?>
